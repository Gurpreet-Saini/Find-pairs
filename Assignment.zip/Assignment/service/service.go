package service

import (
	"errors"

	"assignment/models"
)

type service struct{}

func New() Service {
	return &service{}
}

func (s *service) FindPair(input *models.Input) (*models.Response, error) {
	if len(input.Numbers) == 0 { // checking the array's length
		return nil, errors.New("empty numbers array found")
	}

	var resp models.Response
	indices := map[int]int{}

	for i := range input.Numbers {
		diff := input.Target - input.Numbers[i]
		if v, ok := indices[diff]; ok {
			resp.Solutions = append(resp.Solutions, [2]int{i, v})
		}
		indices[input.Numbers[i]] = i
	}

	return &resp, nil
}
