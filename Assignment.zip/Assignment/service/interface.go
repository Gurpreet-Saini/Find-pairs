package service

import "assignment/models"

type Service interface {
	FindPair(input *models.Input) (*models.Response, error)
}
