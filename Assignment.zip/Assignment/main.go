package main

import (
	"fmt"
	"net/http"

	"assignment/delivery"
	"assignment/service"
)

const HTTP_PORT = "8000"

func main() {
	svc := service.New()
	deliveryLayer := delivery.New(svc)

	http.HandleFunc("/find-pairs", deliveryLayer.FindPairs)

	fmt.Println("Server is running on port:", HTTP_PORT)

	err := http.ListenAndServe(":"+HTTP_PORT, nil)
	if err != nil {
		fmt.Printf("Error while starting the server on PORT: %v, Err: %v", HTTP_PORT, err)
	}
}
