package models

type Input struct {
	Numbers []int `json:"numbers"`
	Target  int   `json:"target"`
}

type Response struct {
	Solutions [][2]int `json:"solutions"`
}
