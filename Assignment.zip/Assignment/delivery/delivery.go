package delivery

import (
	"encoding/json"
	"io"
	"net/http"

	"assignment/models"
	"assignment/service"
)

type delivery struct {
	service service.Service
}

func New(service service.Service) delivery {
	return delivery{service: service}
}

func (d *delivery) FindPairs(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost { // validating if the request method is POST or not
		w.WriteHeader(http.StatusMethodNotAllowed)
		w.Write([]byte("Method not allowed"))
		return
	}

	var reqBody *models.Input
	body, err := io.ReadAll(r.Body) // converting it to the byte
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(`Error while reading request body` + err.Error()))
		return
	}

	err = json.Unmarshal(body, &reqBody) // Parse the request body
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte("Invalid request body"))
		return
	}

	resp, err := d.service.FindPair(reqBody) // call to service layer to find the pairs
	if err != nil {                          //returning the error response
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
		return
	}

	if len(resp.Solutions) == 0 { // if there are no solutions return empty array
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		w.Write([]byte(`{"solutions":[]}`))
		return
	}

	solutions, err := json.Marshal(resp)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}

	// Set Content-Type header and write the response
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(solutions)
}
